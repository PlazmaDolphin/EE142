--- This File is the Write-up ---
Program Made by: Ian Coker '27
Program For: COL Baker's C++ Class

******HELP RECEIVED ASSETS*******
enemy.png       DeviantArt: Sethenius
https://pixeljoint.com/pixelart/43069.htm
    - ship_center.png
    - player_shot.png
    - enemy_shot.png
vectorBold.ttf (on VMIGameEngine/resource):
https://www.fontspace.com/charge-vector-font-f66313

            ***** STORY/OBJECTIVE *****
You are pitoling a spacecraft, attempting to supply weapons
to your allies. But along the way, you get attacked by an
enemy ambush! Can you defeat each enemy wave and warp to safety,
or will your ship turn into swiss cheese in combat?

                *****CONTROLS****
This game uses a unique circular movement system. The direction
you hold is the angle your ship will head towards.
WASD: 8-directional Movement
Spacebar: Fire laser gun
Forward Slash: Also fire laser gun