#include "Gyruss.h"

int main(){
    Gyruss game;
    game.playGame();
    return 0;
}